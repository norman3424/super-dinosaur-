from conftest import login, html

def test_tc03_login_success_opens_catalog(client, user_db):
    # TC-03 — Авторизация пользователя (успешно)
    # Предусловие: пользователь зарегистрирован
    user_db(username="tc03_user", email="tc03@example.com", password="pass123")

    resp = login(client, username="tc03_user", password="pass123", follow=True)

    # Ожидаемый результат: пользователь вошёл (и может открыть каталог)
    assert resp.status_code == 200
    assert "Вы вошли в аккаунт" in html(resp)

    catalog = client.get("/catalog")
    assert catalog.status_code == 200
    assert "<h1>Каталог</h1>" in html(catalog)
