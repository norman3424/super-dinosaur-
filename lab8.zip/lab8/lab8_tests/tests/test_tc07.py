from conftest import html

def test_tc07_open_content_card(client, content_db):
    # TC-07 — Просмотр карточки контента
    movie = content_db(title="TC07 Movie")

    catalog = client.get("/catalog")
    assert catalog.status_code == 200

    # "Нажать на карточку" -> на странице есть ссылка на /movie/<id>
    assert f"/movie/{movie['id']}" in html(catalog)

    page = client.get(f"/movie/{movie['id']}")
    assert page.status_code == 200
    assert "TC07 Movie" in html(page)
