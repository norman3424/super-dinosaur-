collect_ignore = [
    'test_auth.py',
    'test_catalog.py',
    'test_comments.py',
    'test_favorites.py',
]

import sys
from pathlib import Path

import pytest
from werkzeug.security import generate_password_hash

# --- ВАЖНО ---
# PyCharm запускает pytest из папки tests, поэтому добавляем корень проекта в sys.path.
# Тогда `from app import app` будет импортировать ВАШ dinolog/app.py, а не чужой пакет `app` из venv.
PROJECT_ROOT = Path(__file__).resolve().parents[2]  # .../dinolog
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app import app as flask_app  # noqa: E402
from models import db, User, Content, Review  # noqa: E402


@pytest.fixture()
def app(tmp_path):
    """Готовим отдельную тестовую БД (SQLite-файл во временной папке)."""
    db_path = tmp_path / "test.db"

    flask_app.config.update(
        TESTING=True,
        SECRET_KEY="test_secret",
        SQLALCHEMY_DATABASE_URI=f"sqlite:///{db_path}",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )

    with flask_app.app_context():
        db.drop_all()
        db.create_all()
        yield flask_app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def user_db(app):
    """Создать пользователя напрямую в БД (для предусловий). Возвращает dict с id и паролем."""
    def _create(username="user", email="user@example.com", password="pass123"):
        with app.app_context():
            u = User(
                username=username,
                email=email,
                password=generate_password_hash(password),
            )
            db.session.add(u)
            db.session.commit()
            return {"id": u.id, "username": username, "email": email, "password": password}
    return _create


@pytest.fixture()
def content_db(app):
    """Создать контент напрямую в БД. Возвращает dict с id и title."""
    def _create(
        title="Movie",
        description="Desc",
        genre="Action",
        year=2020,
        poster="/static/posters/book.png",
        category="movie",
        is_featured=False,
    ):
        with app.app_context():
            c = Content(
                title=title,
                description=description,
                genre=genre,
                year=year,
                poster=poster,
                category=category,
                is_featured=is_featured,
            )
            db.session.add(c)
            db.session.commit()
            return {"id": c.id, "title": title}
    return _create


def register(client, username, email, password, follow=True):
    return client.post(
        "/register",
        data={"username": username, "email": email, "password": password},
        follow_redirects=follow,
    )


def login(client, username, password, follow=True):
    return client.post(
        "/login",
        data={"username": username, "password": password},
        follow_redirects=follow,
    )


def html(resp) -> str:
    return resp.data.decode("utf-8", errors="ignore")
