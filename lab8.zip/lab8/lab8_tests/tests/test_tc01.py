from models import User
from conftest import register, html

def test_tc01_register_success(client, app):
    # TC-01 — Регистрация пользователя с корректными данными
    # Предусловие: открыта страница регистрации
    page = client.get("/register")
    assert page.status_code == 200

    # Проверяем "маскирование" пароля: поле type="password"
    assert 'type="password"' in html(page)

    # Шаги: ввести логин/пароль и нажать "Зарегистрироваться"
    resp = register(client, username="tc01_user", email="tc01@example.com", password="pass123", follow=True)

    # Ожидаемый результат: пользователь зарегистрирован
    assert resp.status_code == 200
    assert "Регистрация прошла успешно" in html(resp)

    with app.app_context():
        assert User.query.filter_by(username="tc01_user").first() is not None
