from models import Review
from conftest import login, html

def test_tc08_add_comment_success(client, app, user_db, content_db):
    # TC-08 — Добавление комментария (позитив)
    user_db(username="tc08_user", email="tc08@example.com", password="pass123")
    login(client, "tc08_user", "pass123", follow=True)

    movie = content_db(title="TC08 Movie")

    resp = client.post(
        f"/movie/{movie['id']}/comment",
        data={"text": "Отличный фильм!", "rating": "8"},
        follow_redirects=True,
    )

    assert resp.status_code == 200
    assert "Комментарий добавлен" in html(resp)
    assert "Отличный фильм!" in html(resp)

    with app.app_context():
        assert Review.query.filter_by(content_id=movie["id"]).count() == 1
