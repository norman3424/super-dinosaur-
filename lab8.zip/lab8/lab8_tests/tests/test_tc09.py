from conftest import html

def test_tc09_add_comment_without_auth_requires_login(client, content_db):
    # TC-09 — Добавление комментария без авторизации (негатив)
    movie = content_db(title="TC09 Movie")

    resp = client.post(
        f"/movie/{movie['id']}/comment",
        data={"text": "Хочу оставить отзыв", "rating": "7"},
        follow_redirects=True,
    )

    assert resp.status_code == 200
    assert "<h1>Вход</h1>" in html(resp)
    assert "Войдите в аккаунт" in html(resp)
