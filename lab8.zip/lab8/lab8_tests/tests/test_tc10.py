from conftest import html

def test_tc10_search_by_title(client, content_db):
    # TC-10 — Поиск фильма по названию
    content_db(title="Dino Park")
    content_db(title="Some Other Movie")

    resp = client.get("/catalog?q=Dino")
    assert resp.status_code == 200
    page = html(resp)

    assert "Dino Park" in page
    assert "Some Other Movie" not in page
