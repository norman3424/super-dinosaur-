from models import User
from conftest import register, html

def test_tc02_register_duplicate_username(client, app, user_db):
    # TC-02 — Регистрация с существующим логином
    # Предусловие: пользователь уже существует
    user_db(username="dup", email="dup@example.com", password="pass123")

    resp = register(client, username="dup", email="dup2@example.com", password="pass123", follow=True)

    # Ожидаемый результат: сообщение об ошибке
    assert resp.status_code == 200
    assert "уже существует" in html(resp).lower()

    with app.app_context():
        assert User.query.filter_by(username="dup").count() == 1
