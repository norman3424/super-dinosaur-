from conftest import login, html

def test_tc04_login_wrong_password_error(client, user_db):
    # TC-04 — Авторизация с неверным паролем
    user_db(username="tc04_user", email="tc04@example.com", password="correct")

    resp = login(client, username="tc04_user", password="wrong", follow=True)

    # Ожидаемый результат: сообщение об ошибке
    assert resp.status_code == 200
    assert "Неверный логин или пароль" in html(resp)
