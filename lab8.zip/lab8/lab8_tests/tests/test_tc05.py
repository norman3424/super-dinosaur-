from conftest import html

def test_tc05_go_to_register_from_login(client):
    # TC-05 — Переход на страницу регистрации
    login_page = client.get("/login")
    assert login_page.status_code == 200

    # На странице входа есть ссылка "Зарегистрироваться" -> /register
    assert "/register" in html(login_page)

    reg_page = client.get("/register")
    assert reg_page.status_code == 200
    assert "<h1>Регистрация</h1>" in html(reg_page)
