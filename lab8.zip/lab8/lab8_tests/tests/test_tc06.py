from conftest import login, html

def test_tc06_view_catalog_content_list(client, user_db, content_db):
    # TC-06 — Просмотр каталога контента
    # Предусловие: пользователь авторизован
    user_db(username="tc06_user", email="tc06@example.com", password="pass123")
    login(client, "tc06_user", "pass123", follow=True)

    # Чтобы был "список контента" — добавим 1 фильм
    content_db(title="TC06 Movie")

    resp = client.get("/catalog")
    assert resp.status_code == 200
    assert "TC06 Movie" in html(resp)
